﻿namespace PubsFinalProject
{


    public partial class PubsDataSet
    {
    }
}

namespace PubsFinalProject.PubsDataSetTableAdapters {
    
    
    public partial class titlesTableAdapter {
    }
}
